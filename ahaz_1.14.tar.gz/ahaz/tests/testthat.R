library(testthat)
library(ahaz)

test_check("ahaz")
